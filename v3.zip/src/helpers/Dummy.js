import React from 'react';
import './Dummy.scss';

const Dummy = ({currentPage}) => {
    return (
        <div className='overlay'>
            <span />
            {currentPage > 0 && <i>Загружается страница {currentPage}...</i>}
        </div>
    );
};

export default Dummy;
